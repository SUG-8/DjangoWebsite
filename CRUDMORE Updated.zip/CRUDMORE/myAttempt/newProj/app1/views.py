from django.shortcuts import render , redirect
from .forms import MyForm
from .models import MyModel
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout

def parent(request):
    return render(request, 'parent.html',{})


def secondpage(request):
    return render(request, 'secondpage.html',{})

def formpage(request):
    success = False
    new_data=""

    if request.method == 'GET':
        form = MyForm()
    else:
        form = MyForm(request.POST)

        if form.is_valid():
            name = form.cleaned_data["name"]
            venue = form.cleaned_data["venue"]
            dateOfEvent = form.cleaned_data["date_of_event"]
            description = form.cleaned_data["description"]
            attendees = form.cleaned_data['attendees']
            success = True
            form.save()
            new_data = form.cleaned_data
    return render(request, 'formpage.html', {"form":form, "success":success,"new_data":new_data})

#VIEW

def viewALL(request):
    bookingList = MyModel.objects.all()

    return render(request, 'viewALL.html', {'bookingList':bookingList})
#edit

def edit(request, model_id):
    model = MyModel.objects.get(pk=model_id)
    form = MyForm(request.POST or None, instance=model)

    if form.is_valid():
        form.save()
        return redirect('viewALL')
    
    return render(request, 'edit.html', {'model':model, 'form':form})


def delete(request, model_id):
    model = MyModel.objects.get(pk=model_id)
    model.delete()
    return redirect('viewALL')

#LOG IN
def log_in(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.success(request, "There was an error logging in")
            return redirect('log_in')
    else:
        return render(request, 'log_in.html', {})
#LOG OUT

def log_out(request):
    logout(request)
    messages.success(request,"You were logged out")
    return redirect('log_in')

#HOME?
def home(request):
    return render(request, 'home.html', {})




    

