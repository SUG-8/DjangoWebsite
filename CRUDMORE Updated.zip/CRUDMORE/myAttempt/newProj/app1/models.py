from datetime import date
from django.db import models
from multiselectfield import MultiSelectField

class MyModel(models.Model):

    VENUE_OPTIONS = [
        ('NEC', 'National Exhibition Centre'),
        ('NIA', 'National Indoor Arena'),
        ('Civic','Wolverhampton Civic'),
    ]

    ATTENDEE_OPTIONS = [
        ('Steve','Steve'),
        ('Dave','Dave'),
        ('Bruce','Bruce'),
        ('Nicko','Nicko'),
        ('Adrien','Adrien'),
    ]

    name = models.CharField(max_length = 200)
    venue = models.CharField(max_length = 5, choices=VENUE_OPTIONS, default='NEC')
    address = models.CharField(max_length = 200)
    email = models.EmailField(max_length = 100)
    date_of_event = models.DateField(default = date.today)
    description = models.TextField(default="no comment")
    attendees = MultiSelectField(max_length = 100, choices = ATTENDEE_OPTIONS, default= ['Bruce', 'Janick'])
    
