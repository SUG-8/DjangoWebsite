from django import forms
from django.forms import ModelForm
from .models import MyModel

class MyForm(ModelForm):
    class Meta:
        model = MyModel
        fields = ['name', 'address', 'email', 'venue', 'date_of_event', 'description', 'attendees']
        widgets = {
            'name' : forms.TextInput(attrs={'class':'form-control'}),
            'adderess':forms.TextInput(attrs={'class':'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'venue': forms.Select(attrs={'class':'form-control'}),
            'date_of_event': forms.DateInput(attrs={'type':'date', 'class':'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'row':5, 'placeholder': 'Tell us about the event'}),
            'attendees': forms.SelectMultiple(attrs={'class':'form-control','size':6}),
        }
        field_order = ['name','adderess', 'email','venue', 'date_of_event', 'description','attendees']